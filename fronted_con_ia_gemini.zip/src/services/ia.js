// Llamada DIRECTA a la API de Google Gemini desde el navegador (uso personal, plan GRATIS).
// La clave va en tu archivo .env como VITE_GEMINI_API_KEY (se crea gratis en https://aistudio.google.com/apikey).
// ⚠️ Esa clave queda dentro del JavaScript de la app: úsala local o no publiques la app (ver GUIA_IA.md).

const API_KEY = import.meta.env.VITE_GEMINI_API_KEY;
// Modelo con plan gratuito. Si quieres respuestas más precisas, prueba 'gemini-3.5-flash'.
const MODELO = import.meta.env.VITE_GEMINI_MODEL || 'gemini-3.5-flash-lite';

async function llamarGemini({ system, contents, generationConfig = {} }) {
  if (!API_KEY) throw new Error('Falta VITE_GEMINI_API_KEY en tu archivo .env');

  const r = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${MODELO}:generateContent`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-goog-api-key': API_KEY },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: system }] },
        contents,
        generationConfig
      })
    }
  );

  const data = await r.json().catch(() => ({}));
  if (!r.ok) {
    if (r.status === 429) {
      throw new Error('Llegaste al límite gratuito por ahora. Espera un minuto e intenta de nuevo.');
    }
    throw new Error(data?.error?.message || 'Error al consultar la IA');
  }

  const parts = data.candidates?.[0]?.content?.parts || [];
  const texto = parts.map((p) => p.text || '').join('');
  if (!texto) throw new Error('La IA no devolvió respuesta, intenta reformular.');
  return texto;
}

/* ───────── Punto 1: preguntas sobre el negocio ───────── */
export async function preguntarAlNegocio(pregunta, historial = [], contexto) {
  const system = `Eres el asistente del dueño de un pequeño negocio colombiano que produce y vende arroz/comida por lotes.
Respondes en español, claro, breve y amable, usando SOLO los datos del bloque <datos>.
Reglas:
- Los montos están en pesos colombianos (COP); formatéalos como $1.250.000.
- Los totales ya vienen calculados en <datos>: úsalos tal cual, no los recalcules a menos que debas combinarlos.
- Si la respuesta no está en los datos, dilo con honestidad; no inventes cifras.
- Si piden "ganancia", explica brevemente cómo la calculaste (ventas − costo del lote − gastos). Si un lote aún tiene unidades sin vender, su gananciaSobreVentas puede salir negativa solo porque falta vender: menciónalo y da también gananciaEstimadaSiVendeTodo, sin alarmar al dueño.
- Usa listas cortas cuando enumeres clientes o lotes. No uses tablas.

<datos>
${JSON.stringify(contexto)}
</datos>`;

  const contents = [
    ...historial.slice(-8).map((m) => ({
      role: m.rol === 'ia' ? 'model' : 'user',
      parts: [{ text: String(m.texto || '').slice(0, 2000) }]
    })),
    { role: 'user', parts: [{ text: String(pregunta).slice(0, 1000) }] }
  ];

  const respuesta = await llamarGemini({
    system,
    contents,
    generationConfig: { maxOutputTokens: 2048 }
  });
  return { respuesta };
}

/* ───────── Punto 2: texto libre → borrador de venta ───────── */
export async function interpretarVentaIA(texto, clientes = [], lotes = [], hoy) {
  const system = `Conviertes frases dichas por el dueño de un negocio en un borrador de venta.
Hoy es ${hoy}.
Clientes registrados: ${JSON.stringify(clientes)}
Lotes disponibles: ${JSON.stringify(lotes)}

Reglas:
- clienteId: escoge el cliente registrado cuyo nombre mejor coincida (tolera apodos, tildes y errores de dictado como "Doña Marta" ≈ "Marta Gómez"). Si hay duda real entre varios, pon null y explícalo en "aviso".
- Si el cliente mencionado no existe, clienteId = null y pon su nombre en clienteNombreMencionado.
- cantidad: número de unidades vendidas.
- valorUnitario: SOLO si lo dicen (ej. "a 5 mil c/u" = 5000, "a 5.000"). Si no lo dicen, null (la app usará el precio del lote).
- abono: lo que el cliente pagó. Entiende "50 mil" = 50000, "medio millón" = 500000. Si dicen que pagó todo, pagoCompleto = true.
- entrega: "Entregado" solo si dicen que ya se entregó; si no, "Pendiente".
- loteId: solo si mencionan un lote que coincida; si no, null.
- Nunca inventes datos que no estén en la frase.`;

  const salida = await llamarGemini({
    system,
    contents: [{ role: 'user', parts: [{ text: String(texto).slice(0, 600) }] }],
    generationConfig: {
      maxOutputTokens: 1024,
      responseMimeType: 'application/json',
      responseSchema: {
        type: 'OBJECT',
        properties: {
          clienteId: { type: 'STRING', nullable: true },
          clienteNombreMencionado: { type: 'STRING', nullable: true },
          cantidad: { type: 'NUMBER', nullable: true },
          valorUnitario: { type: 'NUMBER', nullable: true },
          abono: { type: 'NUMBER', nullable: true },
          pagoCompleto: { type: 'BOOLEAN' },
          entrega: { type: 'STRING', enum: ['Pendiente', 'Entregado'] },
          loteId: { type: 'STRING', nullable: true },
          aviso: { type: 'STRING', nullable: true }
        },
        required: ['entrega']
      }
    }
  });

  let b;
  try {
    b = JSON.parse(salida);
  } catch {
    throw new Error('No pude interpretar la venta, intenta con otra frase.');
  }

  // Seguridad: los IDs deben existir de verdad
  if (b.clienteId && !clientes.some((c) => c.id === b.clienteId)) b.clienteId = null;
  if (b.loteId && !lotes.some((l) => l.id === b.loteId)) b.loteId = null;
  return { borrador: b };
}
