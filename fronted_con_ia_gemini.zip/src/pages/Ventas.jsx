import { useState, useEffect, useRef } from 'react';
import {
  collection,
  addDoc,
  deleteDoc,
  updateDoc,
  doc,
  onSnapshot,
  query,
  orderBy,
  serverTimestamp
} from 'firebase/firestore';
import { db } from '../firebase';
import TopBar from '../components/TopBar';
import Button from '../components/Button';
import ClienteSelector from '../components/ClienteSelector';
import VentaPorTexto from '../components/VentaPorTexto';
import '../styles/Modulos.css';

const ENTREGAS = ['Pendiente', 'Entregado'];
const ESTADOS  = ['Pendiente', 'Pagado'];

function Ventas({ usuario, onAbrirSidebar }) {
  const [ventas, setVentas] = useState([]);
  const [clientes, setClientes] = useState([]);
  const [lotes, setLotes] = useState([]);
  const [cargando, setCargando] = useState(true);
  const [guardando, setGuardando] = useState(false);
  const [mostrarForm, setMostrarForm] = useState(false);
  const [error, setError] = useState('');

  const [nuevo, setNuevo] = useState({
    clienteId: '',
    cantidad: '',
    valorUnitario: '',
    abono: '',
    entrega: 'Pendiente',
    estado: 'Pendiente',
    loteId: ''
  });

  const [seleccionados, setSeleccionados] = useState([]);
  const [editando, setEditando] = useState(null);
  const [guardandoEdit, setGuardandoEdit] = useState(false);

  // 📄 Paginación (PC)
  const [paginaActual, setPaginaActual] = useState(1);
  const [porPagina, setPorPagina] = useState(10);

  // 📱 Botón "Ver más" (móvil)
  const [mostrarEnMobile, setMostrarEnMobile] = useState(20);

  // 🔍 Buscador
  const [busqueda, setBusqueda] = useState('');

  // 🍚 Filtro por lote
  const [filtroLote, setFiltroLote] = useState('todos');

  // 🚚 Filtro por estado de entrega
  const [filtroEntrega, setFiltroEntrega] = useState('todos');

  // 💵 Filtro por pago (solo los que no han pagado completo)
  const [soloSinPagar, setSoloSinPagar] = useState(false);

  // 🍚 Dropdown custom
  const [dropdownAbierto, setDropdownAbierto] = useState(false);
  const dropdownRef = useRef(null);

  // 🔥 Cargar ventas, clientes y lotes en tiempo real
  useEffect(() => {
    const qVentas = query(collection(db, 'ventas'), orderBy('fecha', 'desc'));
    const unsubVentas = onSnapshot(
      qVentas,
      (snapshot) => {
        setVentas(snapshot.docs.map((d) => ({ id: d.id, ...d.data() })));
        setCargando(false);
      },
      (err) => {
        console.error(err);
        setError('No se pudieron cargar las ventas');
        setCargando(false);
      }
    );

    const qClientes = query(collection(db, 'clientes'), orderBy('nombre'));
    const unsubClientes = onSnapshot(qClientes, (snapshot) => {
      setClientes(snapshot.docs.map((d) => ({ id: d.id, ...d.data() })));
    });

    const qLotes = query(collection(db, 'lotes'), orderBy('fecha', 'desc'));
    const unsubLotes = onSnapshot(qLotes, (snapshot) => {
      setLotes(snapshot.docs.map((d) => ({ id: d.id, ...d.data() })));
    });

    return () => {
      unsubVentas();
      unsubClientes();
      unsubLotes();
    };
  }, []);

  // 🔒 Cerrar dropdown al hacer clic fuera o presionar Escape
  useEffect(() => {
    const handleClickFuera = (e) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setDropdownAbierto(false);
      }
    };

    const handleEsc = (e) => {
      if (e.key === 'Escape') setDropdownAbierto(false);
    };

    document.addEventListener('mousedown', handleClickFuera);
    document.addEventListener('keydown', handleEsc);

    return () => {
      document.removeEventListener('mousedown', handleClickFuera);
      document.removeEventListener('keydown', handleEsc);
    };
  }, []);

  // 📅 Formatear fecha
  const formatearFecha = (fecha) => {
    if (!fecha) return '...';

    if (fecha.toDate) {
      return fecha.toDate().toLocaleDateString('es-CO');
    }

    if (typeof fecha === 'string') {
      if (/^\d{4}-\d{2}-\d{2}$/.test(fecha)) {
        const [yyyy, mm, dd] = fecha.split('-');
        return `${dd}/${mm}/${yyyy}`;
      }
      if (fecha.includes('T')) {
        const [datePart] = fecha.split('T');
        const [yyyy, mm, dd] = datePart.split('-');
        return `${dd}/${mm}/${yyyy}`;
      }
    }

    return new Date(fecha).toLocaleDateString('es-CO');
  };

  // 🎯 Obtener valor unitario de un lote
  const getValorUnitarioLote = (loteId) => {
    if (!loteId) return '';
    const lote = lotes.find((l) => l.id === loteId);
    if (!lote) return '';
    // Intenta varias posibles propiedades
    return (
      lote.valorUnitario ??
      lote.precioUnitario ??
      lote.precio ??
      lote.valorVenta ??
      ''
    );
  };

  // 🎯 Ventas del lote actualmente filtrado (sin aplicar entrega ni búsqueda) —
  // sirve de base para los conteos/resumen de entrega, así respetan el lote elegido
  const ventasDelLoteFiltrado = ventas.filter((v) => {
    if (filtroLote === 'todos') return true;
    if (filtroLote === 'sin-lote') return !v.loteId;
    return v.loteId === filtroLote;
  });

  // 🔍 Filtrar ventas según búsqueda + lote + entrega
  const ventasFiltradas = ventas.filter((v) => {
    if (filtroLote !== 'todos') {
      if (filtroLote === 'sin-lote') {
        if (v.loteId) return false;
      } else if (v.loteId !== filtroLote) {
        return false;
      }
    }

    if (filtroEntrega !== 'todos') {
      const entregaVenta = v.entrega || 'Pendiente';
      if (entregaVenta !== filtroEntrega) return false;
    }

    if (soloSinPagar && v.estado === 'Pagado') return false;

    if (!busqueda.trim()) return true;

    const busq = busqueda.toLowerCase().trim();
    const fechaFormateada = formatearFecha(v.fecha).toLowerCase();

    return (
      (v.clienteNombre || '').toLowerCase().includes(busq) ||
      (v.clienteTelefono || '').toLowerCase().includes(busq) ||
      (v.loteNombre || '').toLowerCase().includes(busq) ||
      fechaFormateada.includes(busq) ||
      String(v.cantidad || '').includes(busq)
    );
  });

  // 🧮 Cálculos del formulario
  const cantidadNum = Number(nuevo.cantidad) || 0;
  const valorNum    = Number(nuevo.valorUnitario) || 0;
  const abonoNum    = Number(nuevo.abono) || 0;

  const totalFormulario   = cantidadNum * valorNum;
  const pagadoFormulario  = abonoNum;
  const saldoFormulario   = totalFormulario - pagadoFormulario;

  const estadoAutomaticoForm =
    totalFormulario > 0 && pagadoFormulario >= totalFormulario
      ? 'Pagado'
      : 'Pendiente';

  // 🧮 Cálculos del modal de edición
  const editCantidad = Number(editando?.cantidad) || 0;
  const editValor    = Number(editando?.valorUnitario) || 0;
  const editAbono    = Number(editando?.abono) || 0;
  const totalEditando  = editCantidad * editValor;
  const pagadoEditando = editAbono;
  const saldoEditando  = totalEditando - pagadoEditando;

  const estadoAutomaticoEdit =
    totalEditando > 0 && pagadoEditando >= totalEditando
      ? 'Pagado'
      : 'Pendiente';

  // 📄 Cálculos de paginación (PC)
  const totalPaginas = Math.ceil(ventasFiltradas.length / porPagina);
  const inicio = (paginaActual - 1) * porPagina;
  const fin = inicio + porPagina;
  const ventasPaginadas = ventasFiltradas.slice(inicio, fin);

  useEffect(() => {
    if (paginaActual > totalPaginas && totalPaginas > 0) {
      setPaginaActual(1);
    }
  }, [porPagina, ventasFiltradas.length, totalPaginas, paginaActual]);

  useEffect(() => {
    setPaginaActual(1);
    setMostrarEnMobile(20);
  }, [busqueda, filtroLote, filtroEntrega, soloSinPagar]);

  const irPagina = (n) => {
    if (n < 1 || n > totalPaginas) return;
    setPaginaActual(n);
  };

  // 🎯 Cuando cambia el lote en el formulario → autocompleta el valor unitario
  useEffect(() => {
    if (!nuevo.loteId) return;
    const valorLote = getValorUnitarioLote(nuevo.loteId);
    if (valorLote !== '') {
      setNuevo((prev) => ({ ...prev, valorUnitario: String(valorLote) }));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [nuevo.loteId]);

  // ✨ IA: prellena el formulario con el borrador interpretado (NO guarda)
  const aplicarBorrador = (b) => {
    const avisos = [];
    const valorHablado = b.valorUnitario != null ? Number(b.valorUnitario) : null;
    const valorLote = b.loteId ? Number(getValorUnitarioLote(b.loteId)) || null : null;
    const valor = valorHablado ?? valorLote;
    const cantidad = b.cantidad != null ? Number(b.cantidad) : null;

    let abono = b.abono != null ? Number(b.abono) : null;
    if (b.pagoCompleto) {
      if (cantidad && valor) abono = cantidad * valor;
      else avisos.push('Dijiste que pagó todo, pero falta el precio para calcular el abono.');
    }

    if (!b.clienteId) {
      avisos.push(
        b.clienteNombreMencionado
          ? `No encontré al cliente "${b.clienteNombreMencionado}". Elígelo o regístralo en Clientes.`
          : 'No identifiqué el cliente, elígelo en la lista.'
      );
    }
    if (!valor) avisos.push('Falta el valor unitario: escríbelo o elige un lote con precio.');

    setNuevo({
      clienteId: b.clienteId || '',
      loteId: b.loteId || '',
      cantidad: cantidad != null ? String(cantidad) : '',
      valorUnitario: valor != null ? String(valor) : '',
      abono: abono != null ? String(abono) : '',
      entrega: b.entrega || 'Pendiente',
      estado: 'Pendiente'
    });
    setMostrarForm(true);

    // El efecto del lote reescribe el valor unitario con el del lote;
    // si el usuario dijo un precio distinto, lo reponemos después.
    if (valorHablado != null && b.loteId) {
      setTimeout(
        () => setNuevo((prev) => ({ ...prev, valorUnitario: String(valorHablado) })),
        50
      );
    }
    return avisos;
  };

  // ➕ Agregar venta
  const agregar = async () => {
    const cliente = clientes.find((c) => c.id === nuevo.clienteId);
    if (!cliente || !nuevo.cantidad || !nuevo.valorUnitario) return;

    const total = cantidadNum * valorNum;
    const pagado = abonoNum;
    const saldo = total - pagado;
    const estadoFinal = saldo <= 0 ? 'Pagado' : 'Pendiente';

    const loteSeleccionado = lotes.find((l) => l.id === nuevo.loteId);

    setGuardando(true);
    setError('');

    try {
      await addDoc(collection(db, 'ventas'), {
        clienteId: cliente.id,
        clienteNombre: cliente.nombre,
        clienteTelefono: cliente.telefono || '',
        cantidad: cantidadNum,
        valorUnitario: valorNum,
        total,
        abono: abonoNum,
        pagado,
        saldo,
        entrega: nuevo.entrega,
        estado: estadoFinal,
        loteId: loteSeleccionado?.id || null,
        loteNombre: loteSeleccionado?.nombre || null,
        fecha: serverTimestamp(),
        creadoPor: usuario?.uid || 'anónimo',
        creadoPorEmail: usuario?.email || 'anónimo'
      });

      setNuevo({
        clienteId: '',
        cantidad: '',
        valorUnitario: '',
        abono: '',
        entrega: 'Pendiente',
        estado: 'Pendiente',
        loteId: ''
      });
      setMostrarForm(false);
    } catch (err) {
      console.error('Error al guardar venta:', err);
      setError('Error: ' + err.message);
    } finally {
      setGuardando(false);
    }
  };

  // ✏️ Guardar edición
  const guardarEdicion = async () => {
    if (!editando) return;
    const cliente = clientes.find((c) => c.id === editando.clienteId);
    if (!cliente || !editando.cantidad || !editando.valorUnitario) return;

    const total = editCantidad * editValor;
    const pagado = editAbono;
    const saldo = total - pagado;
    const estadoFinal = saldo <= 0 ? 'Pagado' : 'Pendiente';

    const loteSeleccionado = lotes.find((l) => l.id === editando.loteId);

    setGuardandoEdit(true);
    setError('');

    try {
      const ref = doc(db, 'ventas', editando.id);
      await updateDoc(ref, {
        clienteId: cliente.id,
        clienteNombre: cliente.nombre,
        clienteTelefono: cliente.telefono || '',
        cantidad: editCantidad,
        valorUnitario: editValor,
        total,
        abono: editAbono,
        pagado,
        saldo,
        entrega: editando.entrega || 'Pendiente',
        estado: estadoFinal,
        loteId: loteSeleccionado?.id || null,
        loteNombre: loteSeleccionado?.nombre || null,
        editadoPor: usuario?.email || 'anónimo'
      });
      setEditando(null);
    } catch (err) {
      console.error('Error al editar venta:', err);
      setError('Error: ' + err.message);
    } finally {
      setGuardandoEdit(false);
    }
  };

  const eliminar = async (id) => {
    if (!window.confirm('¿Eliminar esta venta?')) return;
    try {
      await deleteDoc(doc(db, 'ventas', id));
      setSeleccionados(seleccionados.filter((s) => s !== id));
    } catch (err) {
      console.error('Error al eliminar venta:', err);
      setError(
        `No se pudo eliminar (${err.code || 'error'}): ${err.message}`
      );
    }
  };

  const eliminarSeleccionados = async () => {
    if (seleccionados.length === 0) return;
    if (!window.confirm(`¿Eliminar ${seleccionados.length} venta(s)?`)) return;
    try {
      await Promise.all(
        seleccionados.map((id) => deleteDoc(doc(db, 'ventas', id)))
      );
      setSeleccionados([]);
    } catch (err) {
      console.error('Error al eliminar ventas seleccionadas:', err);
      setError(
        `No se pudieron eliminar las seleccionadas (${err.code || 'error'}): ${err.message}`
      );
    }
  };

  const toggleSeleccion = (id) => {
    setSeleccionados((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  };

  const toggleTodos = () => {
    if (seleccionados.length === ventasPaginadas.length) {
      setSeleccionados((prev) =>
        prev.filter((id) => !ventasPaginadas.some((v) => v.id === id))
      );
    } else {
      const idsPagina = ventasPaginadas.map((v) => v.id);
      setSeleccionados((prev) => [...new Set([...prev, ...idsPagina])]);
    }
  };

  const todosSeleccionados =
    ventasPaginadas.length > 0 &&
    ventasPaginadas.every((v) => seleccionados.includes(v.id));

  const totalVendido = ventasFiltradas.reduce((s, v) => s + (v.total || 0), 0);
  const totalPagado  = ventasFiltradas.reduce((s, v) => s + (v.pagado || 0), 0);
  const totalSaldo   = ventasFiltradas.reduce((s, v) => s + (v.saldo || 0), 0);

  // 🚚 Conteos y totales por estado de entrega (respetando el lote filtrado, no solo la página)
  const ventasPendientesEntrega = ventasDelLoteFiltrado.filter((v) => (v.entrega || 'Pendiente') === 'Pendiente');
  const ventasEntregadas = ventasDelLoteFiltrado.filter((v) => v.entrega === 'Entregado');
  const ventasSinPagar = ventasDelLoteFiltrado.filter((v) => v.estado !== 'Pagado');

  const totalSelVendido = ventas
    .filter((v) => seleccionados.includes(v.id))
    .reduce((s, v) => s + (v.total || 0), 0);
  const totalSelSaldo = ventas
    .filter((v) => seleccionados.includes(v.id))
    .reduce((s, v) => s + (v.saldo || 0), 0);

  const colorEntrega = (e) =>
    e === 'Entregado' ? 'badge-verde' : 'badge-amarillo';

  const colorEstado = (e) =>
    e === 'Pagado' ? 'badge-verde' : 'badge-amarillo';

  const nombreLoteFiltro =
    filtroLote === 'sin-lote'
      ? 'Sin lote'
      : filtroLote === 'todos'
      ? null
      : lotes.find((l) => l.id === filtroLote)?.nombre || '';

  // 🎯 Valor sugerido del lote seleccionado en el form
  const valorSugeridoLote = nuevo.loteId
    ? getValorUnitarioLote(nuevo.loteId)
    : '';

  return (
    <div className="modulo-layout">
      <div className="modulo-main">
        <TopBar
          usuario={usuario}
          titulo="💰 Ventas"
          onAbrirSidebar={onAbrirSidebar}
        />

        <div className="modulo-content">
          <div className="modulo-header">
            <div>
              <h1>Registro de ventas</h1>
              <p>
                Total vendido: <strong>${totalVendido.toLocaleString('es-CO')}</strong>
                {' '}· Pagado: <strong style={{ color: '#2A9D8F' }}>
                  ${totalPagado.toLocaleString('es-CO')}
                </strong>
                {' '}· Saldo: <strong style={{ color: '#F26B7A' }}>
                  ${totalSaldo.toLocaleString('es-CO')}
                </strong>
                {seleccionados.length > 0 && (
                  <>
                    <br />
                    <small>
                      Seleccionado: vendido ${totalSelVendido.toLocaleString('es-CO')} ·
                      saldo pendiente ${totalSelSaldo.toLocaleString('es-CO')}
                    </small>
                  </>
                )}
              </p>
            </div>
            <div className="modulo-acciones">
              {seleccionados.length > 0 && (
                <Button variant="danger" onClick={eliminarSeleccionados} fullWidth={false}>
                  🗑 Eliminar ({seleccionados.length})
                </Button>
              )}
              <Button onClick={() => setMostrarForm(!mostrarForm)} fullWidth={false}>
                {mostrarForm ? '← Volver a la lista' : '➕ Nueva venta'}
              </Button>
            </div>
          </div>

          {/* ✨ Registrar venta con IA (texto o voz) */}
          {clientes.length > 0 && (
            <VentaPorTexto
              clientes={clientes}
              lotes={lotes}
              onBorrador={aplicarBorrador}
            />
          )}

          {/* 🔍 BUSCADOR Y FILTROS */}
          {!mostrarForm && (
            <>
              <div className="filtros-ventas">
                <div className="buscador-ventas">
                  <span className="buscador-icon">🔍</span>
                  <input
                    type="text"
                    placeholder="Buscar por cliente, teléfono, fecha..."
                    value={busqueda}
                    onChange={(e) => setBusqueda(e.target.value)}
                  />
                  {busqueda && (
                    <button
                      className="buscador-limpiar"
                      onClick={() => setBusqueda('')}
                      title="Limpiar búsqueda"
                    >
                      ✖
                    </button>
                  )}
                </div>

                <div className="filtro-lote-ventas" ref={dropdownRef}>
                  <button
                    type="button"
                    className="filtro-lote-trigger"
                    onClick={() => setDropdownAbierto(!dropdownAbierto)}
                  >
                    <span className="filtro-lote-icon">🍚</span>
                    <span className="filtro-lote-label">
                      {filtroLote === 'todos' && (
                        <>📚 Todos los lotes ({ventas.length})</>
                      )}
                      {filtroLote === 'sin-lote' && (
                        <>⚠️ Sin lote ({ventas.filter((v) => !v.loteId).length})</>
                      )}
                      {filtroLote !== 'todos' && filtroLote !== 'sin-lote' && (
                        <>
                          🍚 {lotes.find((l) => l.id === filtroLote)?.nombre} (
                          {ventas.filter((v) => v.loteId === filtroLote).length})
                        </>
                      )}
                    </span>
                    <span className={`filtro-lote-arrow ${dropdownAbierto ? 'abierto' : ''}`}>
                      ▼
                    </span>
                  </button>

                  {dropdownAbierto && (
                    <div className="filtro-lote-menu">
                      <button
                        type="button"
                        className={`filtro-lote-opcion ${
                          filtroLote === 'todos' ? 'activa' : ''
                        }`}
                        onClick={() => {
                          setFiltroLote('todos');
                          setDropdownAbierto(false);
                        }}
                      >
                        <span className="opcion-icon">📚</span>
                        <span className="opcion-texto">Todos los lotes</span>
                        <span className="opcion-cantidad">{ventas.length}</span>
                        {filtroLote === 'todos' && <span className="opcion-check">✓</span>}
                      </button>

                      <button
                        type="button"
                        className={`filtro-lote-opcion ${
                          filtroLote === 'sin-lote' ? 'activa' : ''
                        }`}
                        onClick={() => {
                          setFiltroLote('sin-lote');
                          setDropdownAbierto(false);
                        }}
                      >
                        <span className="opcion-icon">⚠️</span>
                        <span className="opcion-texto">Sin lote</span>
                        <span className="opcion-cantidad">
                          {ventas.filter((v) => !v.loteId).length}
                        </span>
                        {filtroLote === 'sin-lote' && <span className="opcion-check">✓</span>}
                      </button>

                      {lotes.map((l) => {
                        const cantidad = ventas.filter((v) => v.loteId === l.id).length;
                        return (
                          <button
                            key={l.id}
                            type="button"
                            className={`filtro-lote-opcion ${
                              filtroLote === l.id ? 'activa' : ''
                            }`}
                            onClick={() => {
                              setFiltroLote(l.id);
                              setDropdownAbierto(false);
                            }}
                          >
                            <span className="opcion-icon">🍚</span>
                            <span className="opcion-texto">{l.nombre}</span>
                            <span className="opcion-cantidad">{cantidad}</span>
                            {filtroLote === l.id && <span className="opcion-check">✓</span>}
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>

                <div className="filtro-entrega-ventas" style={{ display: 'flex', gap: 6 }}>
                  <button
                    type="button"
                    className={`filtro-entrega-btn ${filtroEntrega === 'todos' ? 'activa' : ''}`}
                    onClick={() => setFiltroEntrega('todos')}
                    title="Mostrar todas"
                  >
                    📦 Todas ({ventasDelLoteFiltrado.length})
                  </button>
                  <button
                    type="button"
                    className={`filtro-entrega-btn ${filtroEntrega === 'Pendiente' ? 'activa' : ''}`}
                    onClick={() => setFiltroEntrega('Pendiente')}
                    title="Ventas que aún hacen falta entregar"
                  >
                    🚚 Por entregar ({ventasPendientesEntrega.length})
                  </button>
                  <button
                    type="button"
                    className={`filtro-entrega-btn ${filtroEntrega === 'Entregado' ? 'activa' : ''}`}
                    onClick={() => setFiltroEntrega('Entregado')}
                    title="Ventas ya entregadas"
                  >
                    ✅ Entregadas ({ventasEntregadas.length})
                  </button>
                  <button
                    type="button"
                    className={`filtro-entrega-btn ${soloSinPagar ? 'activa' : ''}`}
                    onClick={() => setSoloSinPagar(!soloSinPagar)}
                    title="Ventas con pago pendiente"
                  >
                    ⏳ Sin pagar ({ventasSinPagar.length})
                  </button>
                </div>
              </div>

              {(busqueda || filtroLote !== 'todos' || filtroEntrega !== 'todos' || soloSinPagar) && (
                <div className="buscador-resultados">
                  {ventasFiltradas.length === 0 ? (
                    <span style={{ color: '#F26B7A' }}>
                      ❌ No se encontraron ventas
                      {busqueda && <> para "<strong>{busqueda}</strong>"</>}
                      {filtroLote !== 'todos' && (
                        <>
                          {' '}en el lote <strong>{nombreLoteFiltro}</strong>
                        </>
                      )}
                      {filtroEntrega !== 'todos' && (
                        <>
                          {' '}con estado <strong>{filtroEntrega}</strong>
                        </>
                      )}
                      {soloSinPagar && (
                        <>
                          {' '}sin pagar
                        </>
                      )}
                    </span>
                  ) : (
                    <span>
                      ✅ Mostrando <strong>{ventasFiltradas.length}</strong> de{' '}
                      <strong>{ventas.length}</strong> ventas
                      {filtroLote !== 'todos' && (
                        <>
                          {' '}· Lote: <strong>{nombreLoteFiltro}</strong>
                        </>
                      )}
                      {filtroEntrega !== 'todos' && (
                        <>
                          {' '}· Entrega: <strong>{filtroEntrega}</strong>
                        </>
                      )}
                      {soloSinPagar && (
                        <>
                          {' '}· <strong>Sin pagar</strong>
                        </>
                      )}
                      {busqueda && (
                        <>
                          {' '}· Búsqueda: <strong>"{busqueda}"</strong>
                        </>
                      )}
                    </span>
                  )}
                </div>
              )}
            </>
          )}

          {error && <div className="error-msg">{error}</div>}

          {/* ➕ Formulario */}
          {mostrarForm && (
            <div className="form-card">
              <h3>Agregar nueva venta</h3>

              {clientes.length === 0 ? (
                <div className="error-msg">
                  ⚠️ Primero debes registrar al menos un cliente en el módulo <strong>Clientes</strong>.
                </div>
              ) : (
                <>
                  <div className="form-grid">
                    <div className="form-field form-field-full">
                      <label>Cliente</label>
                      <ClienteSelector
                        clientes={clientes}
                        value={nuevo.clienteId}
                        onChange={(id) => setNuevo({ ...nuevo, clienteId: id })}
                      />
                    </div>

                    <div className="form-field form-field-full">
                      <label>Lote (opcional)</label>
                      <select
                        value={nuevo.loteId}
                        onChange={(e) => {
                          const loteId = e.target.value;
                          const valorLote = getValorUnitarioLote(loteId);

                          setNuevo((prev) => ({
                            ...prev,
                            loteId,
                            // 🎯 Autocompleta el valor unitario si el lote lo tiene
                            valorUnitario:
                              loteId && valorLote !== ''
                                ? String(valorLote)
                                : loteId
                                ? prev.valorUnitario
                                : ''
                          }));
                        }}
                      >
                        <option value="">— Sin lote (venta general) —</option>
                        {lotes.map((l) => {
                          const valorLote = getValorUnitarioLote(l.id);
                          return (
                            <option key={l.id} value={l.id}>
                              {l.nombre} · {l.cantidadProducida} producidos ·{' '}
                              {formatearFecha(l.fecha)}
                              {valorLote !== '' &&
                                ` · $${Number(valorLote).toLocaleString(
                                  'es-CO'
                                )} c/u`}
                            </option>
                          );
                        })}
                      </select>
                      <small className="hint">
                        💡 Al elegir un lote, se autocompleta el valor unitario
                      </small>
                    </div>

                    <div className="form-field">
                      <label>Cantidad vendida</label>
                      <input
                        type="number"
                        placeholder="0"
                        min="0"
                        step="1"
                        value={nuevo.cantidad}
                        onChange={(e) =>
                          setNuevo({ ...nuevo, cantidad: e.target.value })
                        }
                      />
                    </div>

                    <div className="form-field">
                      <label>
                        Valor unitario
                        {valorSugeridoLote !== '' && (
                          <span className="label-auto">
                            {' '}
                            ✨ auto del lote
                          </span>
                        )}
                      </label>
                      <input
                        type="number"
                        placeholder="0"
                        min="0"
                        step="0.01"
                        value={nuevo.valorUnitario}
                        onChange={(e) =>
                          setNuevo({ ...nuevo, valorUnitario: e.target.value })
                        }
                      />
                      <small className="hint">
                        💡 Puedes editarlo si aplicas un precio distinto
                      </small>
                    </div>

                    <div className="form-field">
                      <label>💵 Abono inicial</label>
                      <input
                        type="number"
                        placeholder="0"
                        min="0"
                        step="0.01"
                        value={nuevo.abono}
                        onFocus={(e) => {
                          e.target.placeholder = '';
                          if (Number(nuevo.abono) === 0) setNuevo({ ...nuevo, abono: '' });
                        }}
                        onBlur={(e) => {
                          e.target.placeholder = '0';
                        }}
                        onChange={(e) =>
                          setNuevo({ ...nuevo, abono: e.target.value })
                        }
                      />
                      <button
                        type="button"
                        className="btn-pagado-rapido"
                        disabled={totalFormulario <= 0}
                        onClick={() =>
                          setNuevo({ ...nuevo, abono: String(totalFormulario) })
                        }
                      >
                        ✅ Pagado completo (${totalFormulario.toLocaleString('es-CO')})
                      </button>
                      <small className="hint">
                        💡 Cuánto te pagó (puede ser menos del total)
                      </small>
                    </div>

                    <div className="form-field">
                      <label>Entrega</label>
                      <select
                        value={nuevo.entrega}
                        onChange={(e) =>
                          setNuevo({ ...nuevo, entrega: e.target.value })
                        }
                      >
                        {ENTREGAS.map((e) => (
                          <option key={e} value={e}>{e}</option>
                        ))}
                      </select>
                    </div>

                    <div className="form-field">
                      <label>Estado (automático)</label>
                      <div className={`estado-auto-box ${estadoAutomaticoForm === 'Pagado' ? 'estado-auto-pagado' : 'estado-auto-pendiente'}`}>
                        <span className="estado-auto-icon">
                          {estadoAutomaticoForm === 'Pagado' ? '✅' : '⏳'}
                        </span>
                        <span className="estado-auto-texto">{estadoAutomaticoForm}</span>
                        <small className="estado-auto-hint">
                          {estadoAutomaticoForm === 'Pagado'
                            ? 'Pago completo'
                            : 'Falta por cobrar'}
                        </small>
                      </div>
                    </div>

                    <div className="form-field form-field-full">
                      <label>Resumen</label>
                      <div className="total-preview">
                        Total: <strong>${totalFormulario.toLocaleString('es-CO')}</strong>
                        {' '}· Abonado: <strong style={{ color: '#2A9D8F' }}>
                          ${pagadoFormulario.toLocaleString('es-CO')}
                        </strong>
                        {' '}· Saldo: <strong style={{ color: '#F26B7A' }}>
                          ${saldoFormulario.toLocaleString('es-CO')}
                        </strong>
                      </div>
                    </div>
                  </div>

                  <Button
                    onClick={agregar}
                    fullWidth={false}
                    disabled={
                      guardando ||
                      !nuevo.clienteId ||
                      !nuevo.cantidad ||
                      !nuevo.valorUnitario
                    }
                  >
                    {guardando ? 'Guardando...' : 'Guardar venta'}
                  </Button>
                </>
              )}
            </div>
          )}

          {/* 📋 TABLA + CARDS */}
          {!mostrarForm && (
            <div className="dashboard-panel">
              <div className="tabla-ventas-desktop">
                <div className="table-wrapper">
                  <table className="data-table">
                    <thead>
                      <tr>
                        <th style={{ width: '40px' }}>
                          <input
                            type="checkbox"
                            checked={todosSeleccionados}
                            onChange={toggleTodos}
                          />
                        </th>
                        <th>Cliente</th>
                        <th>Cant.</th>
                        <th>Total</th>
                        <th>Abonado</th>
                        <th>Saldo</th>
                        <th>Lote</th>
                        <th>Entrega</th>
                        <th>Estado</th>
                        <th>Fecha</th>
                        <th style={{ width: '100px' }}>Acciones</th>
                      </tr>
                    </thead>
                    <tbody>
                      {cargando ? (
                        <tr>
                          <td colSpan="11" style={{ textAlign: 'center', padding: '30px' }}>
                            Cargando ventas... 🍚
                          </td>
                        </tr>
                      ) : ventasFiltradas.length === 0 ? (
                        <tr>
                          <td
                            colSpan="11"
                            style={{ textAlign: 'center', padding: '40px', color: '#8B7A66' }}
                          >
                            {busqueda || filtroLote !== 'todos' ? (
                              <>
                                🔍 No se encontraron ventas
                                {busqueda && <> para "<strong>{busqueda}</strong>"</>}
                                {filtroLote !== 'todos' && (
                                  <>
                                    {' '}en el lote <strong>{nombreLoteFiltro}</strong>
                                  </>
                                )}
                                <br />
                                <small>Prueba con otro filtro o término de búsqueda</small>
                              </>
                            ) : (
                              <>
                                💰 Aún no hay ventas registradas
                                <br />
                                <small>Haz clic en "➕ Nueva venta" para empezar</small>
                              </>
                            )}
                          </td>
                        </tr>
                      ) : (
                        ventasPaginadas.map((v) => {
                          const activo = seleccionados.includes(v.id);
                          return (
                            <tr key={v.id} className={activo ? 'fila-seleccionada' : ''}>
                              <td>
                                <input
                                  type="checkbox"
                                  checked={activo}
                                  onChange={() => toggleSeleccion(v.id)}
                                />
                              </td>
                              <td>
                                <strong>{v.clienteNombre}</strong>
                                <br />
                                <small style={{ color: '#8B7A66' }}>
                                  {v.clienteTelefono}
                                </small>
                              </td>
                              <td>{v.cantidad}</td>
                              <td>${v.total?.toLocaleString('es-CO')}</td>
                              <td>
                                <strong style={{ color: '#2A9D8F' }}>
                                  ${v.pagado?.toLocaleString('es-CO')}
                                </strong>
                              </td>
                              <td>
                                <strong style={{ color: v.saldo > 0 ? '#F26B7A' : '#8B7A66' }}>
                                  ${v.saldo?.toLocaleString('es-CO')}
                                </strong>
                              </td>
                              <td>
                                {v.loteNombre ? (
                                  <span className="badge badge-verde">
                                    🍚 {v.loteNombre}
                                  </span>
                                ) : (
                                  <span style={{ color: '#8B7A66', fontSize: 12 }}>
                                    —
                                  </span>
                                )}
                              </td>
                              <td>
                                <span className={`badge ${colorEntrega(v.entrega)}`}>
                                  {v.entrega}
                                </span>
                              </td>
                              <td>
                                <span className={`badge ${colorEstado(v.estado)}`}>
                                  {v.estado}
                                </span>
                              </td>
                              <td>{formatearFecha(v.fecha)}</td>
                              <td>
                                <div style={{ display: 'flex', gap: '6px' }}>
                                  <button
                                    className="btn-icon"
                                    title="Editar"
                                    onClick={() =>
                                      setEditando({
                                        ...v,
                                        cantidad: v.cantidad ?? '',
                                        valorUnitario: v.valorUnitario ?? '',
                                        abono: v.abono ?? v.pagado ?? 0,
                                        loteId: v.loteId || ''
                                      })
                                    }
                                  >
                                    ✏️
                                  </button>
                                  <button
                                    className="btn-icon"
                                    title="Eliminar"
                                    onClick={() => eliminar(v.id)}
                                  >
                                    🗑
                                  </button>
                                </div>
                              </td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>

                    {ventasFiltradas.length > 0 && (
                      <tfoot>
                        <tr>
                          <td colSpan="3" style={{ textAlign: 'right', fontWeight: '600' }}>
                            Totales:
                          </td>
                          <td>
                            <strong style={{ color: '#5C3A21' }}>
                              ${totalVendido.toLocaleString('es-CO')}
                            </strong>
                          </td>
                          <td>
                            <strong style={{ color: '#2A9D8F' }}>
                              ${totalPagado.toLocaleString('es-CO')}
                            </strong>
                          </td>
                          <td>
                            <strong style={{ color: '#F26B7A' }}>
                              ${totalSaldo.toLocaleString('es-CO')}
                            </strong>
                          </td>
                          <td colSpan="5"></td>
                        </tr>
                      </tfoot>
                    )}
                  </table>
                </div>

                {ventasFiltradas.length > 0 && (
                  <div className="paginacion">
                    <div className="paginacion-info">
                      Mostrando <strong>{inicio + 1}</strong>-
                      <strong>{Math.min(fin, ventasFiltradas.length)}</strong> de{' '}
                      <strong>{ventasFiltradas.length}</strong> ventas
                    </div>

                    <div className="paginacion-controles">
                      <button
                        className="pag-btn"
                        onClick={() => irPagina(paginaActual - 1)}
                        disabled={paginaActual === 1}
                        title="Anterior"
                      >
                        ◀️
                      </button>

                      <span className="pag-numero">
                        Página <strong>{paginaActual}</strong> de{' '}
                        <strong>{totalPaginas}</strong>
                      </span>

                      <button
                        className="pag-btn"
                        onClick={() => irPagina(paginaActual + 1)}
                        disabled={paginaActual === totalPaginas}
                        title="Siguiente"
                      >
                        ▶️
                      </button>
                    </div>

                    <div className="paginacion-tamano">
                      <label>Mostrar:</label>
                      <select
                        value={porPagina}
                        onChange={(e) => {
                          setPorPagina(Number(e.target.value));
                          setPaginaActual(1);
                        }}
                      >
                        <option value={10}>10</option>
                        <option value={25}>25</option>
                        <option value={50}>50</option>
                        <option value={100}>100</option>
                      </select>
                    </div>
                  </div>
                )}
              </div>

              {/* Vista móvil */}
              <div className="cards-ventas-mobile">
                {cargando ? (
                  <p className="panel-vacio">Cargando ventas... 🍚</p>
                ) : ventasFiltradas.length === 0 ? (
                  <p className="panel-vacio">
                    {busqueda || filtroLote !== 'todos' ? (
                      <>
                        🔍 No se encontraron ventas
                        {busqueda && <> para "<strong>{busqueda}</strong>"</>}
                        {filtroLote !== 'todos' && (
                          <>
                            {' '}en el lote <strong>{nombreLoteFiltro}</strong>
                          </>
                        )}
                        <br />
                        <small>Prueba con otro filtro o término de búsqueda</small>
                      </>
                    ) : (
                      <>
                        💰 Aún no hay ventas registradas
                        <br />
                        <small>Haz clic en "➕ Nueva venta" para empezar</small>
                      </>
                    )}
                  </p>
                ) : (
                  <>
                    {ventasFiltradas.length > 1 && (
                      <label className="card-selector-todos">
                        <input
                          type="checkbox"
                          checked={todosSeleccionados}
                          onChange={toggleTodos}
                        />
                        <span>Seleccionar todos ({ventasFiltradas.length})</span>
                      </label>
                    )}

                    {ventasFiltradas.slice(0, mostrarEnMobile).map((v) => {
                      const activo = seleccionados.includes(v.id);
                      const esPagado = v.estado === 'Pagado';
                      const esEntregado = v.entrega === 'Entregado';

                      return (
                        <div
                          key={v.id}
                          className={`venta-card ${activo ? 'venta-card-activa' : ''}`}
                        >
                          <div
                            className={`venta-card-barra ${
                              esPagado ? 'barra-verde' : 'barra-amarilla'
                            }`}
                          />

                          <div className="venta-card-header">
                            <label className="venta-card-check">
                              <input
                                type="checkbox"
                                checked={activo}
                                onChange={() => toggleSeleccion(v.id)}
                              />
                            </label>
                            <div className="venta-card-cliente">
                              <strong>{v.clienteNombre}</strong>
                              <small>📞 {v.clienteTelefono || 'Sin teléfono'}</small>
                            </div>
                            <div className="venta-card-fecha">
                              <span>{formatearFecha(v.fecha)}</span>
                            </div>
                          </div>

                          <div className="venta-card-total-destacado">
                            <span className="total-label">💰 Total</span>
                            <strong className="total-valor">
                              ${v.total?.toLocaleString('es-CO')}
                            </strong>
                          </div>

                          <div className="venta-card-info">
                            <div className="info-item">
                              <span className="info-label">📦 Cantidad</span>
                              <strong>{v.cantidad}</strong>
                            </div>
                            <div className="info-item">
                              <span className="info-label">✅ Abonado</span>
                              <strong style={{ color: '#2A9D8F' }}>
                                ${v.pagado?.toLocaleString('es-CO')}
                              </strong>
                            </div>
                            <div className="info-item info-item-full">
                              <span className="info-label">⏳ Saldo pendiente</span>
                              <strong
                                style={{
                                  color: v.saldo > 0 ? '#F26B7A' : '#8B7A66',
                                  fontSize: v.saldo > 0 ? '18px' : '15px'
                                }}
                              >
                                ${v.saldo?.toLocaleString('es-CO')}
                              </strong>
                            </div>
                          </div>

                          <div className="venta-card-badges">
                            {v.loteNombre && (
                              <span className="badge badge-verde">🍚 {v.loteNombre}</span>
                            )}
                            <span className={`badge ${colorEntrega(v.entrega)}`}>
                              {esEntregado ? '✅' : '🚚'} {v.entrega}
                            </span>
                            <span className={`badge ${colorEstado(v.estado)}`}>
                              {esPagado ? '💰' : '⏳'} {v.estado}
                            </span>
                          </div>

                          <div className="venta-card-acciones">
                            <button
                              className="btn-accion-card btn-editar"
                              onClick={() =>
                                setEditando({
                                  ...v,
                                  cantidad: v.cantidad ?? '',
                                  valorUnitario: v.valorUnitario ?? '',
                                  abono: v.abono ?? v.pagado ?? 0,
                                  loteId: v.loteId || ''
                                })
                              }
                            >
                              ✏️ Editar
                            </button>
                            <button
                              className="btn-accion-card btn-eliminar"
                              onClick={() => eliminar(v.id)}
                            >
                              🗑 Eliminar
                            </button>
                          </div>
                        </div>
                      );
                    })}

                    {ventasFiltradas.length > mostrarEnMobile && (
                      <button
                        className="btn-ver-mas-mobile"
                        onClick={() => setMostrarEnMobile(mostrarEnMobile + 20)}
                      >
                        ⬇️ Ver más ventas ({ventasFiltradas.length - mostrarEnMobile} restantes)
                      </button>
                    )}

                    <div className="ventas-totales-mobile">
                      <h4 className="totales-titulo">📊 Resumen general</h4>
                      <div className="total-row">
                        <span>💰 Total vendido</span>
                        <strong style={{ color: '#5C3A21' }}>
                          ${totalVendido.toLocaleString('es-CO')}
                        </strong>
                      </div>
                      <div className="total-row">
                        <span>✅ Total abonado</span>
                        <strong style={{ color: '#2A9D8F' }}>
                          ${totalPagado.toLocaleString('es-CO')}
                        </strong>
                      </div>
                      <div className="total-row total-row-destacado">
                        <span>⏳ Saldo por cobrar</span>
                        <strong style={{ color: '#F26B7A' }}>
                          ${totalSaldo.toLocaleString('es-CO')}
                        </strong>
                      </div>
                    </div>
                  </>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* ✏️ MODAL DE EDICIÓN */}
      {editando && (
        <div className="modal-overlay" onClick={() => setEditando(null)}>
          <div className="modal-card" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h3>✏️ Editar venta</h3>
              <button className="modal-close" onClick={() => setEditando(null)}>
                ✖
              </button>
            </div>

            <div className="modal-body">
              <div className="form-grid">
                <div className="form-field form-field-full">
                  <label>Cliente</label>
                  <ClienteSelector
                    clientes={clientes}
                    value={editando.clienteId}
                    onChange={(id) => setEditando({ ...editando, clienteId: id })}
                  />
                </div>

                <div className="form-field form-field-full">
                  <label>Lote (opcional)</label>
                  <select
                    value={editando.loteId || ''}
                    onChange={(e) => {
                      const loteId = e.target.value;
                      const valorLote = getValorUnitarioLote(loteId);

                      setEditando((prev) => ({
                        ...prev,
                        loteId,
                        valorUnitario:
                          loteId && valorLote !== ''
                            ? String(valorLote)
                            : loteId
                            ? prev.valorUnitario
                            : prev.valorUnitario
                      }));
                    }}
                  >
                    <option value="">— Sin lote (venta general) —</option>
                    {lotes.map((l) => (
                      <option key={l.id} value={l.id}>
                        {l.nombre} · {l.cantidadProducida} producidos ·{' '}
                        {formatearFecha(l.fecha)}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="form-field">
                  <label>Cantidad vendida</label>
                  <input
                    type="number"
                    min="0"
                    step="1"
                    value={editando.cantidad}
                    onChange={(e) =>
                      setEditando({ ...editando, cantidad: e.target.value })
                    }
                  />
                </div>

                <div className="form-field">
                  <label>Valor unitario</label>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={editando.valorUnitario}
                    onChange={(e) =>
                      setEditando({ ...editando, valorUnitario: e.target.value })
                    }
                  />
                </div>

                <div className="form-field">
                  <label>💵 Abono</label>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={editando.abono}
                    placeholder="0"
                    onFocus={(e) => {
                      e.target.placeholder = '';
                      if (Number(editando.abono) === 0) setEditando({ ...editando, abono: '' });
                    }}
                    onBlur={(e) => {
                      e.target.placeholder = '0';
                    }}
                    onChange={(e) =>
                      setEditando({ ...editando, abono: e.target.value })
                    }
                  />
                  <button
                    type="button"
                    className="btn-pagado-rapido"
                    disabled={totalEditando <= 0}
                    onClick={() =>
                      setEditando({ ...editando, abono: String(totalEditando) })
                    }
                  >
                    ✅ Pagado completo (${totalEditando.toLocaleString('es-CO')})
                  </button>
                  <small className="hint">
                    💡 Edítalo cuando el cliente pague más
                  </small>
                </div>

                <div className="form-field">
                  <label>Entrega</label>
                  <select
                    value={editando.entrega || 'Pendiente'}
                    onChange={(e) =>
                      setEditando({ ...editando, entrega: e.target.value })
                    }
                  >
                    {ENTREGAS.map((e) => (
                      <option key={e} value={e}>{e}</option>
                    ))}
                  </select>
                </div>

                <div className="form-field">
                  <label>Estado (automático)</label>
                  <div className={`estado-auto-box ${estadoAutomaticoEdit === 'Pagado' ? 'estado-auto-pagado' : 'estado-auto-pendiente'}`}>
                    <span className="estado-auto-icon">
                      {estadoAutomaticoEdit === 'Pagado' ? '✅' : '⏳'}
                    </span>
                    <span className="estado-auto-texto">{estadoAutomaticoEdit}</span>
                    <small className="estado-auto-hint">
                      {estadoAutomaticoEdit === 'Pagado'
                        ? 'Pago completo'
                        : 'Falta por cobrar'}
                    </small>
                  </div>
                </div>

                <div className="form-field form-field-full">
                  <label>Resumen</label>
                  <div className="total-preview">
                    Total: <strong>${totalEditando.toLocaleString('es-CO')}</strong>
                    {' '}· Abonado: <strong style={{ color: '#2A9D8F' }}>
                      ${pagadoEditando.toLocaleString('es-CO')}
                    </strong>
                    {' '}· Saldo: <strong style={{ color: '#F26B7A' }}>
                      ${saldoEditando.toLocaleString('es-CO')}
                    </strong>
                  </div>
                </div>
              </div>
            </div>

            <div className="modal-footer">
              <Button
                variant="danger"
                fullWidth={false}
                onClick={() => setEditando(null)}
              >
                Cancelar
              </Button>
              <Button
                fullWidth={false}
                onClick={guardarEdicion}
                disabled={
                  guardandoEdit ||
                  !editando.clienteId ||
                  !editando.cantidad ||
                  !editando.valorUnitario
                }
              >
                {guardandoEdit ? 'Guardando...' : '💾 Guardar cambios'}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default Ventas;