# IA en tu app del arroz — guía de instalación

Qué se agregó:

| Archivo | Para qué |
|---|---|
| `api/asistente.mjs` | Función en Vercel (gratis). Guarda tu clave de IA y verifica el login |
| `src/services/ia.js` | Llama a la función con el token de Firebase |
| `src/services/contextoNegocio.js` | Lee Firestore y resume ventas, lotes, gastos y clientes |
| `src/components/AsistenteIA.jsx` | **Punto 1:** chat flotante ✨ en todas las pantallas |
| `src/components/VentaPorTexto.jsx` | **Punto 2:** "Registrar con IA" (texto o voz) en Ventas |
| `src/styles/Asistente.css` | Estilos de ambos |
| `src/App.jsx`, `src/pages/Ventas.jsx` | Editados para conectar lo anterior |

## Pasos

1. **Copia** `api/` a la RAÍZ de tu proyecto (junto a `package.json`, no dentro de `src/`) y `src/` encima de la tuya.
2. **Clave de IA:** crea cuenta en https://console.anthropic.com, carga un saldo pequeño (con 5 USD alcanza para miles de consultas con el modelo por defecto) y crea una API key.
3. **Sube el proyecto a GitHub** y en https://vercel.com importa el repo (plan gratis). Vercel detecta Vite solo.
4. En Vercel → Settings → Environment Variables agrega:
   - `ANTHROPIC_API_KEY` = tu clave (empieza por `sk-ant-`)
   - `FIREBASE_API_KEY` = el mismo valor de tu `VITE_FIREBASE_API_KEY`
   - `ALLOWED_EMAILS` = (recomendado) tu correo y el de quien use la app, separados por coma
   - Las `VITE_FIREBASE_*` que ya usas
5. Redespliega. Listo.

## Notas importantes

- **La clave nunca va en el frontend.** Por eso existe `api/asistente.mjs`.
- Firebase gratis (Spark) está bien: no usamos Cloud Functions. El asistente lee tus datos con `getDocs` (con caché de 60 s) para cuidar las 50.000 lecturas diarias gratis.
- Si abres la app desde otro dominio (ej. Firebase Hosting) en vez de Vercel, crea `.env` con `VITE_API_BASE=https://tu-proyecto.vercel.app`.
- En `npm run dev` local las rutas `/api` no existen; usa `vercel dev` o apunta `VITE_API_BASE` a tu despliegue.
- El dictado por voz funciona en Chrome/Edge/Android (no en todos los navegadores).
- La IA **nunca guarda** una venta: solo prellena el formulario y tú confirmas.
- Modelo por defecto: `claude-haiku-5-5` (barato y rápido). Puedes cambiarlo con `ANTHROPIC_MODEL`.

## Probar

- Chat ✨: "¿Quién me debe plata?", "¿Cuánto vendí este mes?", "¿Qué lote me dejó más?"
- Ventas → caja "Registrar con IA": "Le vendí 20 a Marta, abonó 50 mil", "Marta pagó todo, 15 unidades, ya se las entregué".
