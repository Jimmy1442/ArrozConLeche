import { auth } from '../firebase';

// En desarrollo local, apunta a tu despliegue de Vercel (ej. https://mi-app.vercel.app)
// En producción (mismo dominio en Vercel) déjalo vacío.
const BASE = import.meta.env.VITE_API_BASE || '';

async function llamar(body) {
  const user = auth.currentUser;
  if (!user) throw new Error('Debes iniciar sesión');
  const token = await user.getIdToken();

  const r = await fetch(`${BASE}/api/asistente`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    },
    body: JSON.stringify(body)
  });

  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.error || 'Error al consultar la IA');
  return data;
}

export const preguntarAlNegocio = (pregunta, historial, contexto) =>
  llamar({ modo: 'consulta', pregunta, historial, contexto });

export const interpretarVentaIA = (texto, clientes, lotes, hoy) =>
  llamar({ modo: 'venta', texto, clientes, lotes, hoy });
