# IA en tu app del arroz — guía (versión personal, sin servidor)

La app llama directo a la IA desde el navegador. No necesitas Vercel ni Cloud Functions.

| Archivo | Para qué |
|---|---|
| `src/services/ia.js` | Llama a la IA (clave desde `.env`) |
| `src/services/contextoNegocio.js` | Lee Firestore y resume ventas, lotes, gastos y clientes |
| `src/components/AsistenteIA.jsx` | **Punto 1:** chat flotante ✨ en todas las pantallas |
| `src/components/VentaPorTexto.jsx` | **Punto 2:** "Registrar con IA" (texto o voz) en Ventas |
| `src/styles/Asistente.css` | Estilos |
| `src/App.jsx`, `src/pages/Ventas.jsx` | Editados para conectar lo anterior |

## Pasos

1. Copia la carpeta `src/` encima de la de tu proyecto.
2. Crea una API key en https://console.anthropic.com (carga un saldo pequeño, ej. 5 USD).
3. En el `.env` de tu proyecto (junto a las `VITE_FIREBASE_*`) agrega:
   ```
   VITE_ANTHROPIC_API_KEY=sk-ant-...
   ```
   Opcional: `VITE_ANTHROPIC_MODEL=claude-haiku-5-5` (por defecto; barato y rápido).
4. Reinicia `npm run dev`. Listo.

## ⚠️ Seguridad: lo único que debes tener claro

Al estar en el frontend, la clave queda dentro del JavaScript de la app. Si solo la corres en tu computador (`npm run dev`) o desde tu celular en tu red, no hay problema.

Si algún día la publicas (Firebase Hosting, Netlify, etc.), cualquiera que abra la página puede sacar la clave del código, aunque haya login. Para protegerte:
- Entra a console.anthropic.com → Limits y pon un **límite de gasto mensual bajo**.
- No subas el `.env` a GitHub (debe estar en `.gitignore`).
- Si sospechas que se filtró, borra la clave y crea otra.

## Probar

- Chat ✨: "¿Quién me debe plata?", "¿Cuánto vendí este mes?", "¿Qué lote me dejó más?"
- Ventas → "Registrar con IA": "Le vendí 20 a Marta, abonó 50 mil", "Marta pagó todo, 15 unidades, ya se las entregué".
- La IA nunca guarda una venta: solo prellena el formulario y tú confirmas.
- El dictado por voz funciona en Chrome/Edge/Android.
