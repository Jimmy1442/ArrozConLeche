// Llamada DIRECTA a la API de Anthropic desde el navegador (uso personal).
// La clave va en tu archivo .env como VITE_ANTHROPIC_API_KEY.
// ⚠️ Esa clave queda dentro del JavaScript de la app: no publiques la app en internet
//    sin pensarlo (ver GUIA_IA.md). Úsala local (npm run dev) o con límite de gasto.

const API_KEY = import.meta.env.VITE_ANTHROPIC_API_KEY;
const MODELO = import.meta.env.VITE_ANTHROPIC_MODEL || 'claude-haiku-5-5';

async function llamarClaude(body) {
  if (!API_KEY) throw new Error('Falta VITE_ANTHROPIC_API_KEY en tu archivo .env');

  const r = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': API_KEY,
      'anthropic-version': '2023-06-01',
      // Requerido por Anthropic para llamadas desde el navegador
      'anthropic-dangerous-direct-browser-access': 'true'
    },
    body: JSON.stringify({ model: MODELO, ...body })
  });

  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data?.error?.message || 'Error al consultar la IA');
  return data;
}

/* ───────── Punto 1: preguntas sobre el negocio ───────── */
export async function preguntarAlNegocio(pregunta, historial = [], contexto) {
  const system = `Eres el asistente del dueño de un pequeño negocio colombiano que produce y vende arroz/comida por lotes.
Respondes en español, claro, breve y amable, usando SOLO los datos del bloque <datos>.
Reglas:
- Los montos están en pesos colombianos (COP); formatéalos como $1.250.000.
- Los totales ya vienen calculados en <datos>: úsalos tal cual, no los recalcules a menos que debas combinarlos.
- Si la respuesta no está en los datos, dilo con honestidad; no inventes cifras.
- Si piden "ganancia", explica brevemente cómo la calculaste (ventas − costo del lote − gastos). Si un lote aún tiene unidades sin vender, su gananciaSobreVentas puede salir negativa solo porque falta vender: menciónalo y da también gananciaEstimadaSiVendeTodo, sin alarmar al dueño.
- Usa listas cortas cuando enumeres clientes o lotes. No uses tablas.

<datos>
${JSON.stringify(contexto)}
</datos>`;

  const messages = [
    ...historial.slice(-8).map((m) => ({
      role: m.rol === 'ia' ? 'assistant' : 'user',
      content: String(m.texto || '').slice(0, 2000)
    })),
    { role: 'user', content: String(pregunta).slice(0, 1000) }
  ];

  const data = await llamarClaude({ max_tokens: 800, system, messages });
  return { respuesta: data.content?.map((b) => b.text || '').join('') || '' };
}

/* ───────── Punto 2: texto libre → borrador de venta ───────── */
export async function interpretarVentaIA(texto, clientes = [], lotes = [], hoy) {
  const system = `Conviertes frases dichas por el dueño de un negocio en un borrador de venta.
Hoy es ${hoy}.
Clientes registrados: ${JSON.stringify(clientes)}
Lotes disponibles: ${JSON.stringify(lotes)}

Reglas:
- clienteId: escoge el cliente registrado cuyo nombre mejor coincida (tolera apodos, tildes y errores de dictado como "Doña Marta" ≈ "Marta Gómez"). Si hay duda real entre varios, pon null y explícalo en "aviso".
- Si el cliente mencionado no existe, clienteId = null y pon su nombre en clienteNombreMencionado.
- cantidad: número de unidades vendidas.
- valorUnitario: SOLO si lo dicen (ej. "a 5 mil c/u" = 5000, "a 5.000"). Si no lo dicen, null (la app usará el precio del lote).
- abono: lo que el cliente pagó. Entiende "50 mil" = 50000, "medio millón" = 500000, "pagó todo" = pagoCompleto true.
- entrega: "Entregado" solo si dicen que ya se entregó; si no, "Pendiente".
- loteId: solo si mencionan un lote que coincida; si no, null.
- Nunca inventes datos que no estén en la frase.`;

  const tool = {
    name: 'borrador_venta',
    description: 'Registra el borrador de venta interpretado',
    input_schema: {
      type: 'object',
      properties: {
        clienteId: { type: ['string', 'null'] },
        clienteNombreMencionado: { type: ['string', 'null'] },
        cantidad: { type: ['number', 'null'] },
        valorUnitario: { type: ['number', 'null'] },
        abono: { type: ['number', 'null'] },
        pagoCompleto: { type: 'boolean' },
        entrega: { type: 'string', enum: ['Pendiente', 'Entregado'] },
        loteId: { type: ['string', 'null'] },
        aviso: { type: ['string', 'null'], description: 'Dudas o datos que faltan, en una frase corta' }
      },
      required: ['clienteId', 'cantidad', 'entrega']
    }
  };

  const data = await llamarClaude({
    max_tokens: 500,
    system,
    tools: [tool],
    tool_choice: { type: 'tool', name: 'borrador_venta' },
    messages: [{ role: 'user', content: String(texto).slice(0, 600) }]
  });

  const uso = data.content?.find((b) => b.type === 'tool_use');
  if (!uso) throw new Error('No pude interpretar la venta');
  const b = uso.input;

  // Seguridad: los IDs deben existir de verdad
  if (b.clienteId && !clientes.some((c) => c.id === b.clienteId)) b.clienteId = null;
  if (b.loteId && !lotes.some((l) => l.id === b.loteId)) b.loteId = null;
  return { borrador: b };
}
